# BeSmartHack
Creating website for low incoe persons in Baltimore

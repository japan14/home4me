# ***Home4Me***
### Description
This project was created to provide quick and seamless access to information about resources for users in need of immediate shelter or transportation. This tool provides information on nearby shelters, food resources, and available transporation based on geolocation.



import React from 'react'
import "./Navbar.css";


function Navbar(){
    return(
        <div>
           <header className="header">
            <h1 className="h1"> Home4Me</h1>
           </header>

        </div>
    )
}

export default Navbar;